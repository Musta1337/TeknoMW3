:: ---------------- Ignore this ----------------
@echo off
:: ---------------------------------------------
@SETLOCAL ENABLEEXTENSIONS
@CD /D "%~dp0"
:: ---------------------------------------------



:: Server Name
:: Changes the title of the CMD window that was opened when you launched this BAT.
::   * No, it doesn't affect the server console window or the server name.
set ServerName=[TG] TeknoMW3 Server


:: Server Visibility
:: 1 - Dedicated LAN Server
:: 2 - Dedicated Internet Server
set ServerVisibility=2


:: Server IP
:: Internal IPv4 address that the server will use.
:: Default: localhost 
set GameIP=localhost


:: Game Port (net_port)
:: - Values from 0 to 65535
::   * Forward this port for UDP!
set GamePort=27017


:: Master Server (server browser) Port (net_masterServerPort)
:: - Values from 0 to 65535
::   * Forward this port for UDP!
::     * If the value is not in the range of 27017-27027, you may not see the server in the LAN server list.
set MasterServerPort=27018


:: Open Game Port (net_queryPort)
:: - Values from 0 to 65535
::   * This port is not relevant, just give it a unique value.
set QueryPort=27019


:: Authentication Port (net_authPort)
:: - Values from 0 to 65535
::   * Use this port for Admin Tools like B3 & IW4MAdmin
set AuthPort=8766


:: Specify the Server Configuration file (which is in the "admin" folder)
::   * Don't forget to edit "Default.dspl" to specify maps and game modes.
set ServerCFG=Server.cfg


:: Launch Parameters
:: Add them with a space, for example: LaunchParameters=XXX YYY ZZZ
:: -enable_b3          - Enables support for B3 & IW4MAdmin
:: -secure_b3          - Adds security for B3 & IW4MAdmin
:: -enable_rcon        - Enable Server Rcon (required for B3 & IW4MAdmin, or Rcon access via ingame console)
:: -no_integrity       - Skips SHA-256 Map checks
:: -enable_slow_motion - Slow Motion Killcam
set LaunchParameters=-no_integrity


:: Start Map Rotation
:: Start the rotation, and, therefore, the server.
:: No  - Server starts partially (doesn't load map, scripts, etc)
:: Yes - Server starts completely
set StartServer=Yes



:: ---------------------------------------------

:: ---------------- Ignore this ----------------
title TeknoMW3 - Dedicated Server : %ServerName%
:: ---------------------------------------------
if "%ServerVisibility%"=="1" (
    set Visibility=LAN
) else if "%ServerVisibility%"=="2" (
    set Visibility=Internet
)
:: ---------------------------------------------
if "%StartServer%"=="No" (
    set StartMapRot=
) else if "%StartServer%"=="Yes" (
    set StartMapRot=start_map_rotate
)
:: ---------------------------------------------


:: ---------------------------------------------
:: Ignore this too...
:: Unless you know what you're doing.
:: ---------------------------------------------
cls
echo.
echo ///////////////////////////////////////////
echo ////              WARNING              ////
echo ///////////////////////////////////////////
echo.
echo If you want to close your Dedicated Server:
echo 1. Close this window.
echo 2. Close the server window.
echo.
echo.
echo ///////////////////////////////////////////
echo ////            EXTRA INFO             ////
echo ///////////////////////////////////////////
echo.
echo - Server Name               : %ServerName%
echo - Server Visibility         : %Visibility%
echo - Secure Game Port          : %GamePort%
echo - Master Server Port        : %MasterServerPort%
echo - Open Game Port            : %QueryPort%
echo - Authentication Port       : %AuthPort%
echo - Server Configuration File : %ServerCFG%
echo - Launch Parameters         : %LaunchParameters%
echo - Start Map Rotation        : %StartServer%
:SV
echo.
echo.
echo ---------------------------------------------------------------
echo [%date% - %time%] Starting the Dedicated Server...
start /wait /abovenormal TeknoMW3_Server_Launcher.exe %LaunchParameters% +set dedicated "%ServerVisibility%" +set net_ip "%GameIP%" +set net_port "%GamePort%" +set net_masterServerPort "%MasterServerPort%" +set net_queryPort "%QueryPort%" +set net_authPort "%AuthPort%" +set sv_config "%ServerCFG%" +%StartMapRot%
echo [%date% - %time%] WARNING: The server has stopped.
echo [%date% - %time%] Restarting...
echo ---------------------------------------------------------------
goto SV