Name:		mw3demoinfo

Build:		0.55

Author:		CyboPat

Info:		Utility to show some info from Call of Duty Modern Warfare 3 demo files (*.demo)

Web:		http://www.cybopat.net/mw3demoinfo

Email:		cybopat@seznam.cz


Release history:

- 0.55	* first release

If you get "Component 'MSCOMCTL.OCX' or one of its dependencies not correctly registered: a file is missing or invalid" error pls do as so.

1) Unzip the "MSCOMCTL.zip" and place the dll in this directory C:\Windows\SysWOW64

2) Browse to your command prompt shortcut via Start-->All Programs-->Accessories-->Command Prompt. Right click on that Command Prompt icon and choose to Run as administrator.  Click Yes to tell UAC you really want to run it.

   When the black window opens with your command prompt, type this in:

   cd<push spacebar>C:\Windows\SysWOW64 <push Enter key>

   The prompt should change to:  C:\Windows\SysWOW64

   Then type:

   regsvr32<push spacebar>mscomctl.ocx <push Enter key>

   If you get a Window that pops up and says, "DllRegisterServer in mscomctl.ocx succeeded" then click OK & you're done! Try & run the program again.