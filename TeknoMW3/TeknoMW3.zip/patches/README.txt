REQUIREMENTS:
- Installation of "Call of Duty: Modern Warfare 3 - Dedicated Server" from Steam (steam://install/42750).
- Installation of "Call of Duty: Modern Warfare 3 - Multiplayer" from Steam, if you own the game (steam://install/42690).
- Only the English version and original game files from Steam are supported.
- The folder "patches" must be located in the root directory of your MW3 game folder (example: C:/TeknoMW3/patches).


NOTE:
- This package does NOT contain any game files or copyrighted material.

